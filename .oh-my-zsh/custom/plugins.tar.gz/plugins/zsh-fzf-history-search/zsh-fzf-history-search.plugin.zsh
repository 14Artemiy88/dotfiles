0=${(%):-%N}
source ${0:A:h}/zsh-fzf-history-search.zsh
